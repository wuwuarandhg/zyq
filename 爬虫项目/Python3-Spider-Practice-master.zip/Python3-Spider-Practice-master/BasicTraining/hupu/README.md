- ## 虎扑论坛步行街

- 爬取时间：2019-10-12

- 爬取难度：★★☆☆☆☆

- 请求链接：https://bbs.hupu.com/bxj

- 爬取目标：爬取虎扑论坛步行街的帖子，包含主题，作者，发布时间等，数据保存到 MongoDB 数据库

- 涉及知识：请求库 requests、解析库 Beautiful Soup、数据库 MongoDB 的操作

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/102528442

- 个人博客链接：https://www.itrhx.com/2019/10/12/A55-pyspider-hupu/

- 效果截图：

![01](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A55/01.png)