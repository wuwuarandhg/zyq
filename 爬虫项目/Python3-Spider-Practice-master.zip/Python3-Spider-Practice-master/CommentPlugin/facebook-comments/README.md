- ## Facebook 评论插件、留言外挂程序采集

- 实现时间：2021-05-30

- 实现难度：★★★☆☆☆

- 实现目标：采集 Facebook 评论插件、留言外挂程序的所有评论。

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/117398369

- Facebook 评论插件官网：https://developers.facebook.com/products/social-plugins/comments

- 本采集代码适用于 Facebook 评论插件的评论采集。仅用于 Python 编程技术交流！

- 效果截图：

![](https://img-blog.csdnimg.cn/20210530222125607.png)

![](https://img-blog.csdnimg.cn/20210530222125750.png)
