- ## 58同城武汉出租房

- 爬取时间：2019-10-21

- 爬取难度：★★★☆☆☆

- 请求链接：https://wh.58.com/chuzu/

- 爬取目标：58同城武汉出租房的所有信息

- 涉及知识：网站加密字体的攻克、请求库 requests、解析库 Beautiful Soup、数据库 MySQL 的操作

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/102668128

- 个人博客链接：https://www.itrhx.com/2019/10/21/A58-pyspider-58tongcheng/

- 效果截图：

![11](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A58/11.png)
