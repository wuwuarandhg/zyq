# 携程 eleven 参数
# 详细教程关注公众号： Python编程与实战！

1.采用websocket通信连接浏览器和服务器
2.Python文件是将我们要构造的JS发送到浏览器，通过油猴脚本注入在浏览器环境中执行。
3.油猴脚本
4.node 服务

来源: https://www.cnblogs.com/re-is-good/p/12864805.html


