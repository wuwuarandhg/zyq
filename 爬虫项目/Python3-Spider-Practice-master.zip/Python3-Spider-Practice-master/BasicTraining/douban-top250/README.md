- ## 豆瓣电影 TOP250

- 爬取时间：2019-09-27

- 爬取难度：★★☆☆☆☆

- 请求链接：https://movie.douban.com/top250 以及每部电影详情页

- 爬取目标：爬取榜单上每一部电影详情页的数据，保存为 CSV 文件；下载所有电影海报到本地

- 涉及知识：请求库 requests、解析库 lxml、Xpath 语法、正则表达式、CSV 和二进制数据储存、列表操作

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/101572275

- 个人博客链接：https://www.itrhx.com/2019/09/28/A52-pyspider-doubantop250/

- 效果截图：

![03](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A52/03.png)

![04](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A52/04.png)
