// 加载核心加密库
var CryptoJS = require("crypto-js");

console.log(CryptoJS.SHA1("123456").toString());