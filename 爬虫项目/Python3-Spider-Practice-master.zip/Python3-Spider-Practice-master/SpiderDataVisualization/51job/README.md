# 前程无忧招聘信息爬取 + 数据可视化

**2020年10月测试，增加了反爬，此代码已失效！！！**

- 爬取时间：2020-07-11

- 实现目标：根据用户输入的关键字爬取相关职位信息存入 MongoDB，读取数据进行可视化展示。

- 涉及知识：请求库 requests、Xpath 语法、数据库 MongoDB、数据处理 Numpy、Pandas、数据可视化 Matplotlib。

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/107315136

- 个人博客链接：https://www.itrhx.com/2020/07/13/A90-pyspider-51job/

- MongoDB 数据截图：

![06](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A90/06.png)

- CSV 文件截图：

![07](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A90/07.png)

- JSON 文件截图：

![08](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A90/08.png)

- 关系图：

![09](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A90/09.png)

![10](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A90/10.png)
