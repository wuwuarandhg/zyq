- ## 模拟登陆哔哩哔哩

- 登录时间：2019-10-21

- 实现难度：★★★☆☆☆

- 请求链接：https://passport.bilibili.com/login

- 实现目标：模拟登陆哔哩哔哩，攻克滑动验证码

- 涉及知识：滑动验证码的攻克、自动化测试工具 Selenium 的使用

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/102649689

- 个人博客链接：https://www.itrhx.com/2019/10/21/A56-pyspider-bilibili-login/

- 效果截图：（关键信息已经过打码处理）

![04](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A56/bilibili.gif)
