# Python编程与实战 JSCrack
# 详细教程关注公众号： Python编程与实战！
## 声明：本文只用于学习研究，禁止用于非法用途，如有侵权，请联系我删除，谢谢！
Python爬虫进阶 JS 解密逆向实战
1. iBank登录
2. 加速乐 cookie 破解
3. 手机贝贝网登录
4. 中国国航登录
5. 中国空气质量参数加密破解
6. 中国土地市场
7. 中国电信登录
8. 美团 token 破解
9. myToken 热搜榜破解
10. 七麦数据
11. 淘宝信用查询网
12. 自媒体工具新榜登录
13. 药监局瑞数加密破解
14. 芒果TV登录
15. 爱应用登录
16. 开源中国登录
17. 锦江酒店/7天
18. 携程eleven参数
19. 市场监督管理局(SCJDGLJ)

JS加密分析破解说明：
1. [JS逆向之贝贝网登录](https://mp.weixin.qq.com/s/Ex93COLBX3_MMhIIXwozYg)
2. [JS逆向之电信登录](https://mp.weixin.qq.com/s/P27oJGafyHsOnxptgHiUPQ)
3. [JS逆向之国航登录](https://mp.weixin.qq.com/s/YWgMoGn4_YVhCPXPOAmrkA)
4. [JS逆向之新榜登录](https://mp.weixin.qq.com/s/548sZpUE1xq2lCs-olVIzQ)
5. [JS逆向入门篇](https://mp.weixin.qq.com/s/xb8VdJGD-DgQzq8yWOBpag)
6. [JS逆向X果TV登录](https://mp.weixin.qq.com/s/mVDR6daS5B4QQJX5IDjSag)
7. [JS逆向某酒店登录](https://mp.weixin.qq.com/s/eXMgPm4VhJcY54VFb0-ljQ)
8. [JS逆向RSA加密网站合集](https://mp.weixin.qq.com/s/FQ_FJKkrecHnHsQQP7UNHA)
9. [某验滑动验证码加密分析还原](https://mp.weixin.qq.com/s/jjy8DUSLW73shyDtCXmeYw)
geetest

安卓APP逆向篇：

1. [XXS](https://mp.weixin.qq.com/s/MW2BQcQyN1A88ljYWQWz6w)
2. [XX通](https://mp.weixin.qq.com/s/D7gWwvaA9Vjd8ub8THrf0Q)
3. [X力播](https://mp.weixin.qq.com/s/1RcPLeBHzOJcPiOzK3NDqQ)
4. [XX书](https://mp.weixin.qq.com/s/t_KHnIVnO0XqVSPe_uCRXQ)


二: 关于本人

公众号：Python编程与实战，欢迎关注一起探讨学习，获取更多知识

![](https://upload-images.jianshu.io/upload_images/16366265-2e1f6469129a3637.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

