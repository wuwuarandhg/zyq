


// var url = "https%3A%2F%2Fs.taobao.com%2Fsearch%3Fajax%3Dtrue%26commend%3Dall%26ssid%3Ds5-e%26search_type%3Ditem%26sourceId%3Dtb.index%26tab%3Dall%26_input_charset%3DUTF-8%26q%3D%25E6%2589%258B%25E6%259C%25BA%26filter%3Dreserve_price%5B%5D%26sort%3D%26loc%3D";
// var param =   "id=" + new Date().getTime().toString(36) + new Date().getTime().toString(36) + "&type=TaobaoItemRank&url=" + url + "&filter=" + "tb2262493" + "&first=" + 177 + "&last=" + 220;
//
// console.log(param);
//
function f() {
    var url = "https%3A%2F%2Fs.taobao.com%2Fsearch%3Fajax%3Dtrue%26commend%3Dall%26ssid%3Ds5-e%26search_type%3Ditem%26sourceId%3Dtb.index%26tab%3Dall%26_input_charset%3DUTF-8%26q%3D%25E6%2589%258B%25E6%259C%25BA%26filter%3Dreserve_price%5B%5D%26sort%3D%26loc%3D";
    var param = "id=" + new Date().getTime().toString(36) + new Date().getTime().toString(36) + "&type=TaobaoItemRank&url=" + url + "&filter=" + "tb2262493" + "&first=" + 177 + "&last=" + 220;
    return param
}

(function () {
    var url = "https%3A%2F%2Fs.taobao.com%2Fsearch%3Fajax%3Dtrue%26commend%3Dall%26ssid%3Ds5-e%26search_type%3Ditem%26sourceId%3Dtb.index%26tab%3Dall%26_input_charset%3DUTF-8%26q%3D%25E6%2589%258B%25E6%259C%25BA%26filter%3Dreserve_price%5B%5D%26sort%3D%26loc%3D";
    var param = "id=" + new Date().getTime().toString(36) + new Date().getTime().toString(36) + "&type=TaobaoItemRank&url=" + url + "&filter=" + "tb2262493" + "&first=" + 177 + "&last=" + 220;
    console.log(param);
    return param
})();