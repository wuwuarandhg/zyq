- ## 猫眼电影 TOP100

- 爬取时间：2019-09-23

- 爬取难度：★☆☆☆☆☆

- 请求链接：https://maoyan.com/board/4

- 爬取目标：猫眼 TOP100 的电影名称、排名、主演、上映时间、评分、封面图地址，数据保存为 CSV 文件

- 涉及知识：请求库 requests、解析库 lxml、Xpath 语法、CSV 文件储存

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/101230024

- 个人博客链接：https://www.itrhx.com/2019/09/24/A51-pyspider-maoyantop100/

- 效果截图：

![01](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A51/01.png)
