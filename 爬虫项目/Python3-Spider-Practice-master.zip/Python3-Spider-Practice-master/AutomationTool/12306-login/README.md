- ## 模拟登陆12306

- 登录时间：2019-10-21

- 实现难度：★★★☆☆☆

- 请求链接：https://kyfw.12306.cn/otn/resources/login.html

- 实现目标：模拟登陆中国铁路12306，攻克点触验证码

- 涉及知识：点触验证码的攻克、自动化测试工具 Selenium 的使用、对接在线打码平台

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/102662630

- 个人博客链接：https://www.itrhx.com/2019/10/21/A57-pyspider-12306-login/

- 效果截图：（关键信息已经过打码处理）

![02](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A57/12306.gif)
