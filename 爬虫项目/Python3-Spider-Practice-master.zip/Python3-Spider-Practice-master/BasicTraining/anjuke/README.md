- ## 安居客武汉二手房

- 爬取时间：2019-10-09

- 爬取难度：★★☆☆☆☆

- 请求链接：https://wuhan.anjuke.com/sale/

- 爬取目标：爬取武汉二手房每一条售房信息，包含地理位置、价格、面积等，保存为 CSV 文件

- 涉及知识：请求库 requests、解析库 Beautiful Soup、CSV 文件储存、列表操作、分页判断

- CSDN 链接：https://itrhx.blog.csdn.net/article/details/102468535

- 个人博客链接：https://www.itrhx.com/2019/10/09/A54-pyspider-anjuke/

- 效果截图：

![03](https://cdn.jsdelivr.net/gh/TRHX/ImageHosting/ITRHX-PIC/A54/03.png)
