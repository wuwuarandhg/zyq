- ## Vuukle 评论插件采集

- 实现时间：2021-05-31

- 实现难度：★★☆☆☆☆

- 实现目标：采集 Vuukle 评论插件的所有评论。

- Vuukle 评论插件官网：https://vuukle.com/

- 本采集代码适用于 Vuukle 评论插件的评论采集。仅用于 Python 编程技术交流！

- 效果截图：

![](https://img-blog.csdnimg.cn/2021053101143820.png)
